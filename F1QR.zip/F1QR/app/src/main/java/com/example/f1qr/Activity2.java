package com.example.f1qr;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.SimpleAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Activity2 extends MainActivity {

    private static String url = resultGlobal;

    // JSON Node names
    private static final String TAG_DRIVERS = "drivers";
    private static final String TAG_BIO = "bio";
    private static final String TAG_FLAPS = "flaps";
    private static final String TAG_FNAME = "fname";
    private static final String TAG_LNAME = "lname";
    private static final String TAG_PODIUMS = "podiums";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

    // Calling async task to get json
        new GetDrivers().execute();
    }

    private class GetDrivers extends AsyncTask<Void, Void, Void> {

        // Hashmap for ListView
        ArrayList<HashMap<String, String>> driverList;
        ProgressDialog proDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
// Showing progress loading dialog
            proDialog = new ProgressDialog(Activity2.this);
            proDialog.setMessage("Please wait...");
            proDialog.setCancelable(false);
            proDialog.show();
        }

        @Override
        protected Void doInBackground(Void... arg0) {
// Creating service handler class instance
            WebRequest webreq = new WebRequest();

// Making a request to url and getting response
            String jsonStr = webreq.makeWebServiceCall(url, WebRequest.GETRequest);

            Log.d("Response: ", "> " + jsonStr);

            driverList = ParseJSON(jsonStr);

            return null;
        }

        @Override
        protected void onPostExecute(Void requestresult) {
            super.onPostExecute(requestresult);
// Dismiss the progress dialog
            if (proDialog.isShowing())
                proDialog.dismiss();
/**
 * Updating received data from JSON into ListView
 * */
            ListAdapter adapter = new SimpleAdapter(
                    Activity2.this, driverList,
                    R.layout.list_item, new String[]{TAG_FNAME, TAG_LNAME,
                    TAG_BIO}, new int[]{R.id.fname,
                    R.id.lname, R.id.bio});

            setListAdapter(adapter);
        }

        private void setListAdapter(ListAdapter adapter) {
        }

    }


    private ArrayList<HashMap<String, String>> ParseJSON(String json) {
        if (json != null) {
            try {
                // Hashmap for ListView
                ArrayList<HashMap<String, String>> formulaList = new ArrayList<HashMap<String, String>>();
                JSONObject jsonObj = new JSONObject(json);

                // Getting JSON Array node
                JSONArray drivers = jsonObj.getJSONArray(TAG_DRIVERS);

                // looping through All drivers
                for (int i = 0; i < drivers.length(); i++) {
                    JSONObject c = drivers.getJSONObject(i);

                    String bio = c.getString(TAG_BIO);
                    String flaps = c.getString(TAG_FLAPS);
                    String fname = c.getString(TAG_FNAME);
                    String lname = c.getString(TAG_LNAME);
                    String podiums = c.getString(TAG_PODIUMS);


                    // tmp hashmap for single driver
                    HashMap<String, String> driver = new HashMap<String, String>();

                    // adding every child node to HashMap key => value
                    driver.put(TAG_BIO, bio);
                    driver.put(TAG_FLAPS, flaps);
                    driver.put(TAG_FNAME, fname);

                    // adding driver to students list
                    formulaList.add(driver);
                }
                return formulaList;
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        } else {
            Log.e("ServiceHandler", "No data received from HTTP request");
            return null;
        }
    }

}